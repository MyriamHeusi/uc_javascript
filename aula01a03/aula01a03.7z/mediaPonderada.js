//declararvariavel
let n1;
let n2;
let n3;
let n4;
let mediaPonderada;

//iniciar as variaveis
n1=0;
n2=0;
n3=0;
n4=0;
mediaPonderada=0;

//coleta/entrada de dados
n1=4;
n2=7;
n3=3;
n4=25;

//processamento
mediaPonderada=((n1*1)+(n2*2)+(n3*3)+(n4*4))/(1+2+3+4);

//saida
console.log("Media Poderada: " + mediaPonderada);