//Definir o tamanho do lado do quadrado
var lado = 4; // tamanho do lado em centímetros

//Calcular o perímetro
var perimetro = 4 * lado;

// Calcular a área
var area = lado * lado;

//Exibir os resultados
console.log("Perímetro do quadrado:", perimetro, "cm");
console.log("Área do quadrado:", area, "cm²");