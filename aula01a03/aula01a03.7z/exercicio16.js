// Definir o ano de nascimento e o ano atual manualmente
var anoNascimento = 1989;
var anoAtual = 2024; // Suponha que o ano atual seja 2024

// Calcular a idade atual
var idadeAtual = anoAtual - anoNascimento;

// Definir o ano desejado para calcular a idade futura
var anoDesejado = 2028;

// Calcular a idade da pessoa no ano desejado (2028)
var idadeFutura = anoDesejado - anoNascimento;

// Exibir os resultados
console.log("Idade atual da pessoa:", idadeAtual, "anos");
console.log("Idade da pessoa em 2028:", idadeFutura, "anos");