//declaracao de variavel
let x = 1;
let y = 2;

//processando
let resultado = x+y;

console.log(resultado);

